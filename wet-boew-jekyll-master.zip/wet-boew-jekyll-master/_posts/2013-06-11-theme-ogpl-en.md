---
published: true
layout: "theme-ogpl/default"
permalink: "2013-06-11-theme-ogpl-en.html"
title: "Example blog post - OGPL theme"
language: en
altLangPrefix: "2013-06-11-theme-ogpl"
dateModified: :year:month:day
description: English description / Description en anglais
---

Introductory paragraph of a blog post using the OGPL theme.
