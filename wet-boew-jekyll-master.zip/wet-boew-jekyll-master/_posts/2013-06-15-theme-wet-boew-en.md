---
published: true
layout: "theme-wet-boew/default"
permalink: "2013-06-15-theme-wet-boew-en.html"
title: "Example blog post - WET theme"
language: en
altLangPrefix: "2013-06-15-theme-wet-boew"
dateModified: :year:month:day
description: English description / Description en anglais
---

Introductory paragraph of a blog post using the WET theme.
