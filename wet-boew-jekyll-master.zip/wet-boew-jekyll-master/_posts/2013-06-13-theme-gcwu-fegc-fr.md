---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "2013-06-13-theme-gcwu-fegc-fr.html"
title: "Exemple d'un article de blogue - Thème de la facilité d'emploi Web GC"
language: fr
altLangPrefix: "2013-06-13-theme-gcwu-fegc"
dateModified: :year:month:day
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: :year:month:day
subject: French subject terms / Termes de sujet en français
---

Paragraphe d'introduction d'un article de blog en utilisant le thème de la facilité d'emploi Web GC.
