---
published: true
layout: "theme-base/default"
permalink: "2013-06-14-theme-base-en.html"
title: "Example blog post - Base theme"
language: en
altLangPrefix: "2013-06-14-theme-base"
dateModified: :year:month:day
description: English description / Description en anglais
---

Introductory paragraph of a blog post using the Base theme.
