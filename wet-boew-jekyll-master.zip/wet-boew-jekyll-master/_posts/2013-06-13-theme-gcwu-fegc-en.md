---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "2013-06-13-theme-gcwu-fegc-en.html"
title: "Example blog post - GC Web Usability theme"
language: en
altLangPrefix: "2013-06-13-theme-gcwu-fegc"
dateModified: :year:month:day
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: :year:month:day
subject: English subject terms / Termes de sujet en anglais
---

Introductory paragraph of a blog post using the GC Web Usability theme.
