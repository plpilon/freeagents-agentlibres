---
published: true
layout: "theme-base/default"
permalink: "2013-06-14-theme-base-fr.html"
title: "Exemple d'un article de blogue - Thème de base"
language: fr
altLangPrefix: "2013-06-14-theme-base"
dateModified: :year:month:day
description: French description / Description en français
---

Paragraphe d'introduction d'un article de blog en utilisant le thème de base.
