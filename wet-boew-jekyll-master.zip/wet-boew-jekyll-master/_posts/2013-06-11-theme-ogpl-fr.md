---
published: true
layout: "theme-ogpl/default"
permalink: "2013-06-11-theme-ogpl-fr.html"
title: "Exemple d'un article de blogue - Thème de la PGO"
language: fr
altLangPrefix: "2013-06-11-theme-ogpl"
dateModified: :year:month:day
description: French description / Description en français
---

Paragraphe d'introduction d'un article de blog en utilisant le thème de la PGO.
