---
published: true
layout: "theme-wet-boew/default"
permalink: "2013-06-15-theme-wet-boew-fr.html"
title: "Exemple d'un article de blogue - Thème de la BOEW"
language: fr
altLangPrefix: "2013-06-15-theme-wet-boew"
dateModified: :year:month:day
description: French description / Description en français
---

Paragraphe d'introduction d'un article de blog en utilisant le thème de la BOEW.
