---
published: true
layout: "theme-gc-intranet/default"
permalink: "2013-06-12-theme-gc-intranet-en.html"
title: "Example blog post - GC Web Usability Intranet theme"
language: en
altLangPrefix: "2013-06-12-theme-gc-intranet"
dateModified: :year:month:day
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: :year:month:day
subject: English subject terms / Termes de sujet en anglais
---

Introductory paragraph of a blog post using the GC Web Usability Intranet theme.
