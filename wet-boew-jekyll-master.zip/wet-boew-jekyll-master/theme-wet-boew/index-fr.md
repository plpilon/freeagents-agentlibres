---
published: true
layout: "theme-wet-boew/default"
permalink: "theme-wet-boew/index-fr.html"
title: "Thème de la BOEW"
language: fr
altLangPrefix: index
dateModified: "2014-05-27"
description: "Thème de la BOEW - Variant pour Jekyll - Boîte à outils de l'expérience Web (BOEW)"
---

## Pages Web normales

* [Page de contenu](content-fr.html)
* [Page de contenu - Menu secondaire](content-secmenu-fr.html)
* [Page de contenu - Sans recherche ou lien de sélection de la langue](content-nosearchlang-fr.html)
* [Page de contenu - Sans menu du site ou fil d'Ariane](content-nositemenubc-fr.html)
* [Page de contenu - Sans recherche, lien de sélection de la langue, menu du site ou fil d'Ariane](content-nosearchlangsitemenubc-fr.html)

## Articles de blogue

* [Article de blogue](../2013-06-15-theme-wet-boew-fr.html)
