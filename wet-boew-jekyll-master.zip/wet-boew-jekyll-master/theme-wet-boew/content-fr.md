---
published: true
layout: "theme-wet-boew/default"
permalink: "theme-wet-boew/content-fr.html"
title: "Page de contenu"
language: fr
altLangPrefix: content
dateModified: "2014-05-27"
description: French description / Description en français
---

