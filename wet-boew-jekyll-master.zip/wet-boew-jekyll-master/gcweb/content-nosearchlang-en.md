---
published: true
layout: "gcweb/default"
permalink: "gcweb/content-nosearchlang-en.html"
title: "Content page - No search or language selection link"
language: en
altLangPrefix: "content-nosearchlang"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
description: English description / Description en anglais
---

