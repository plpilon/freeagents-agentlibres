---
published: true
layout: "gcweb/default"
permalink: "gcweb/content-fr.html"
title: "Page de contenu"
language: fr
altLangPrefix: "content"
dateModified: "2014-05-27"
description: French description / Description en français
---

