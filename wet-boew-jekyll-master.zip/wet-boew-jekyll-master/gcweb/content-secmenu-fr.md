---
published: true
layout: "gcweb/default"
permalink: "gcweb/content-secmenu-fr.html"
title: "Page de contenu - Menu secondaire"
language: fr
altLangPrefix: "content-secmenu"
dateModified: "2014-05-27"
secondarymenu: true
description: French description / Description en français
---

