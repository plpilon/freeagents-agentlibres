---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-secmenu-en.html"
title: "Content page - Secondary menu"
language: en
altLangPrefix: "content-secmenu"
dateModified: "2014-05-27"
secondarymenu: true
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: "2014-05-27"
subject: English subject terms / Termes de sujet en anglais
---

