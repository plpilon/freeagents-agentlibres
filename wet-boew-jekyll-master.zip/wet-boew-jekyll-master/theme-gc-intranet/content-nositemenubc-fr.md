---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-nositemenubc-fr.html"
title: "Page de contenu - Sans menu du site ou fil d'Ariane"
language: fr
altLangPrefix: "content-nositemenubc"
dateModified: "2014-05-27"
sitemenu: false
breadcrumb: false
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: "2014-05-27"
subject: French subject terms / Termes de sujet en français
---

