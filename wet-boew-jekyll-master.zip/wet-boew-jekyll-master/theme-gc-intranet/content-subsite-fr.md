---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-subsite-fr.html"
title: "Page de contenu - Sous-site"
language: fr
altLangPrefix: "content-subsite"
dateModified: "2014-05-27"
subsite: true
subsiteUrl: "#"
subsiteTitle: "Nom du sous-site"
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: "2014-05-27"
subject: French subject terms / Termes de sujet en français
---

