---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-nositemenubc-en.html"
title: "Content page - No site menu or breadcrumb trail"
language: en
altLangPrefix: "content-nositemenubc"
dateModified: "2014-05-27"
sitemenu: false
breadcrumb: false
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: "2014-05-27"
subject: English subject terms / Termes de sujet en anglais
---

