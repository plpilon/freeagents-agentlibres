---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-secmenu-fr.html"
title: "Page de contenu - Menu secondaire"
language: fr
altLangPrefix: "content-secmenu"
dateModified: "2014-05-27"
secondarymenu: true
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: "2014-05-27"
subject: French subject terms / Termes de sujet en français
---

