---
published: true
layout: "theme-gc-intranet/default"
permalink: "theme-gc-intranet/content-subsite-en.html"
title: "Content page - Sub-site"
language: en
altLangPrefix: "content-subsite"
dateModified: "2014-05-27"
subsite: true
subsiteUrl: "#"
subsiteTitle: "Sub-site name"
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: "2014-05-27"
subject: English subject terms / Termes de sujet en anglais
---

