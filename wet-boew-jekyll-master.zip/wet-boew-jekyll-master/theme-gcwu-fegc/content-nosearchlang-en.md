---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "theme-gcwu-fegc/content-nosearchlang-en.html"
title: "Content page - No search or language selection link"
language: en
altLangPrefix: "content-nosearchlang"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
description: English description / Description en anglais
creator: English name of the content author / Nom en anglais de l'auteur du contenu
dateIssued: "2014-05-27"
subject: English subject terms / Termes de sujet en anglais
---

