---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "theme-gcwu-fegc/content-nosearchlang-fr.html"
title: "Page de contenu - Sans recherche ou lien de sélection de la langue"
language: fr
altLangPrefix: "content-nosearchlang"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: "2014-05-27"
subject: French subject terms / Termes de sujet en français
---

