---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "theme-gcwu-fegc/index-fr.html"
title: "Thème de la facilité d’emploi Web du gouvernement du Canada"
language: fr
altLangPrefix: index
dateModified: "2014-08-16"
description: "Thème de la facilité d’emploi Web du gouvernement du Canada - Variant pour Jekyll - Boîte à outils de l'expérience Web (BOEW)"
---

## Pages Web normales

* [Page de contenu](content-fr.html)
* [Page de contenu - Menu secondaire](content-secmenu-fr.html)
* [Page de contenu - Sans recherche ou lien de sélection de la langue](content-nosearchlang-fr.html)
* [Page de contenu - Sans menu du site ou fil d'Ariane](content-nositemenubc-fr.html)
* [Page de contenu - Sans recherche, lien de sélection de la langue, menu du site ou fil d'Ariane](content-nosearchlangsitemenubc-fr.html)

## Articles de blogue

* [Article de blogue](../2013-06-13-theme-gcwu-fegc-fr.html)
