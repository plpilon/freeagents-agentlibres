---
published: true
layout: "theme-gcwu-fegc/default"
permalink: "theme-gcwu-fegc/content-nosearchlangsitemenubc-fr.html"
title: "Page de contenu - Sans recherche, lien de sélection de la langue, menu du site ou fil d'Ariane"
language: fr
altLangPrefix: "content-nosearchlangsitemenubc"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
sitemenu: false
breadcrumb: false
description: French description / Description en français
creator: French name of the content author / Nom en français de l'auteur du contenu
dateIssued: "2014-05-27"
subject: French subject terms / Termes de sujet en français
---

