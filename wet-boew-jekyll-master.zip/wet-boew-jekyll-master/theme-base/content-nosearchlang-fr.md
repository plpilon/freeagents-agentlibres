---
published: true
layout: "theme-base/default"
permalink: "theme-base/content-nosearchlang-fr.html"
title: "Page de contenu - Sans recherche ou lien de sélection de la langue"
language: fr
altLangPrefix: "content-nosearchlang"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
description: French description / Description en français
---

