---
published: true
layout: "theme-base/default"
permalink: "theme-base/index-fr.html"
title: "Thème de la base"
language: fr
altLangPrefix: index
dateModified: "2014-08-16"
description: "Thème de la base - Variant pour Jekyll - Boîte à outils de l'expérience Web (BOEW)"
---

## Pages Web normales

* [Page de contenu](content-fr.html)
* [Page de contenu - Menu secondaire](content-secmenu-fr.html)
* [Page de contenu - Sans recherche ou lien de sélection de la langue](content-nosearchlang-fr.html)
* [Page de contenu - Sans menu du site ou fil d'Ariane](content-nositemenubc-fr.html)
* [Page de contenu - Sans recherche, lien de sélection de la langue, menu du site ou fil d'Ariane](content-nosearchlangsitemenubc-fr.html)

## Articles de blogue

* [Article de blogue](../2013-06-14-theme-base-fr.html)
