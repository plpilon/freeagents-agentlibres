---
published: true
layout: "theme-base/default"
permalink: "theme-base/content-nosearchlangsitemenubc-en.html"
title: "Content page - No search, language selection link, site menu or breadcrumb trail"
language: en
altLangPrefix: "content-nosearchlangsitemenubc"
dateModified: "2014-05-27"
sitesearch: false
languagetoggle: false
sitemenu: false
breadcrumb: false
description: English description / Description en anglais
---

